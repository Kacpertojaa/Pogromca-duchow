using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneData : MonoBehaviour
{
    public static int MenuView = 0;
    public static int MapView = 1;
    public static int CarView = 2;
    public static int GhostHunt1 = 3;
}
